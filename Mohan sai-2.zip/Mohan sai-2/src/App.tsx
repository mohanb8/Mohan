import React, { useEffect } from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate, useLocation } from 'react-router-dom';
import { AuthProvider, useAuth } from './context/AuthContext';
import { BlockchainProvider } from './context/BlockchainContext';
import Navbar from './components/Navbar';
import HomePage from './pages/HomePage';
import LoginPage from './pages/LoginPage';
import AddDocumentPage from './pages/AddDocumentPage';
import ViewDocumentsPage from './pages/ViewDocumentsPage';
import SearchPage from './pages/SearchPage';
import UserDocumentsPage from './pages/UserDocumentsPage';
import DocumentHistoryPage from './pages/DocumentHistoryPage';

// Protected route component
const ProtectedRoute: React.FC<{ element: React.ReactNode }> = ({ element }) => {
  const { isAuthenticated } = useAuth();
  const location = useLocation();
  
  if (!isAuthenticated) {
    return <Navigate to="/login" state={{ from: location }} replace />;
  }
  
  return <>{element}</>;
};

// Admin route component
const AdminRoute: React.FC<{ element: React.ReactNode }> = ({ element }) => {
  const { user, isAuthenticated } = useAuth();
  const location = useLocation();
  
  if (!isAuthenticated) {
    return <Navigate to="/login" state={{ from: location }} replace />;
  }
  
  if (user?.role !== 'admin') {
    return <Navigate to="/" replace />;
  }
  
  return <>{element}</>;
};

// User route component
const UserRoute: React.FC<{ element: React.ReactNode }> = ({ element }) => {
  const { user, isAuthenticated } = useAuth();
  const location = useLocation();
  
  if (!isAuthenticated) {
    return <Navigate to="/login" state={{ from: location }} replace />;
  }
  
  return <>{element}</>;
};

// Auth check component
const AuthCheck: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const { currentAuthStep } = useAuth();
  const location = useLocation();
  
  if (location.pathname !== '/login' && location.pathname !== '/' && location.pathname !== '/search' && currentAuthStep !== 'complete') {
    return <Navigate to="/login" replace />;
  }
  
  return <>{children}</>;
};

function AppContent() {
  const { currentAuthStep } = useAuth();
  const location = useLocation();
  
  useEffect(() => {
    // If user is in the middle of authentication and tries to navigate away, redirect back to login
    if (currentAuthStep !== 'complete' && currentAuthStep !== 'credentials' && 
        location.pathname !== '/login' && location.pathname !== '/' && location.pathname !== '/search') {
      // We don't redirect here to avoid infinite loops, but we handle it in the AuthCheck component
    }
  }, [location, currentAuthStep]);
  
  return (
    <AuthCheck>
      <div className="min-h-screen bg-gray-50 flex flex-col">
        <Navbar />
        <main className="flex-grow">
          <Routes>
            <Route path="/" element={<HomePage />} />
            <Route path="/login" element={<LoginPage />} />
            <Route path="/search" element={<SearchPage />} />
            <Route path="/admin/add-document" element={<AdminRoute element={<AddDocumentPage />} />} />
            <Route path="/admin/view-documents" element={<AdminRoute element={<ViewDocumentsPage />} />} />
            <Route path="/document/:documentId/history" element={<ProtectedRoute element={<DocumentHistoryPage />} />} />
            <Route path="/user/documents" element={<UserRoute element={<UserDocumentsPage />} />} />
            <Route path="*" element={<Navigate to="/" replace />} />
          </Routes>
        </main>
        <footer className="bg-gray-800 text-white py-4 text-center text-sm">
          &copy; {new Date().getFullYear()} E-Vault Blockchain Legal Records | Secure Document Management
        </footer>
      </div>
    </AuthCheck>
  );
}

function App() {
  return (
    <Router>
      <AuthProvider>
        <BlockchainProvider>
          <AppContent />
        </BlockchainProvider>
      </AuthProvider>
    </Router>
  );
}

export default App;