import { google } from 'googleapis';
import { authenticate } from '@google-cloud/local-auth';
import { Buffer } from 'buffer';

const SCOPES = ['https://www.googleapis.com/auth/gmail.send'];

let authClient: any = null;

async function getAuthClient() {
  if (authClient) {
    return authClient;
  }

  try {
    authClient = await authenticate({
      keyfilePath: './src/credentials.json',
      scopes: SCOPES,
    });
    return authClient;
  } catch (error) {
    console.error('Error authenticating with Google:', error);
    throw new Error('Failed to authenticate with Google');
  }
}

export async function sendEmail(to: string, subject: string, body: string, attachmentPath?: string) {
  try {
    const auth = await getAuthClient();
    const gmail = google.gmail({ version: 'v1', auth });

    // Create email content with proper MIME formatting
    const emailLines = [
      `From: "E-Vault System" <${auth.email}>`,
      `To: ${to}`,
      'Content-Type: text/html; charset=utf-8',
      'MIME-Version: 1.0',
      `Subject: ${subject}`,
      '',
      body,
    ];

    const email = emailLines.join('\r\n').trim();

    // Properly encode the email content
    const encodedEmail = Buffer.from(email)
      .toString('base64')
      .replace(/\+/g, '-')
      .replace(/\//g, '_')
      .replace(/=+$/, '');

    // Send email with error handling
    try {
      const res = await gmail.users.messages.send({
        userId: 'me',
        requestBody: {
          raw: encodedEmail,
        },
      });

      return {
        success: true,
        id: res.data.id || '',
        threadId: res.data.threadId || '',
        labelIds: res.data.labelIds || [],
      };
    } catch (sendError) {
      console.error('Error sending email:', sendError);
      return {
        success: false,
        error: 'Failed to send email',
      };
    }
  } catch (error) {
    console.error('Error in email service:', error);
    return {
      success: false,
      error: 'Email service error',
    };
  }
}