import twilio from 'twilio';

// Get environment variables with fallbacks
const accountSid = process.env.TWILIO_ACCOUNT_SID || '';
const authToken = process.env.TWILIO_AUTH_TOKEN || '';
const fromNumber = process.env.TWILIO_WHATSAPP_NUMBER || '';

// Create Twilio client only if credentials are available
const client = accountSid && authToken ? twilio(accountSid, authToken) : null;

export async function sendWhatsAppMessage(to: string, message: string, mediaUrl?: string) {
  try {
    // Validate client and credentials
    if (!client || !fromNumber) {
      console.error('WhatsApp service not properly configured');
      return {
        success: false,
        error: 'WhatsApp service not configured',
      };
    }

    // Validate phone number format
    const formattedTo = to.startsWith('+') ? to : `+${to}`;
    
    const messageOptions: any = {
      from: `whatsapp:${fromNumber}`,
      to: `whatsapp:${formattedTo}`,
      body: message,
    };

    if (mediaUrl) {
      messageOptions.mediaUrl = [mediaUrl];
    }

    try {
      const response = await client.messages.create(messageOptions);

      return {
        success: true,
        id: response.sid,
        status: response.status,
      };
    } catch (sendError) {
      console.error('Error sending WhatsApp message:', sendError);
      return {
        success: false,
        error: 'Failed to send WhatsApp message',
      };
    }
  } catch (error) {
    console.error('Error in WhatsApp service:', error);
    return {
      success: false,
      error: 'WhatsApp service error',
    };
  }
}