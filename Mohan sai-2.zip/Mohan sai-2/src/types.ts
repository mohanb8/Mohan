export interface Document {
  id: string;
  title: string;
  documentType: string;
  description: string;
  parties: string[];
  uid: string;
  createdAt: string;
  updatedAt?: string;
  fileUrl?: string;
  hash: string;
  blockNumber: number;
  previousHash: string;
  owner?: string;
  sharedWith?: string[];
  location?: {
    address: string;
    coordinates?: {
      latitude: number;
      longitude: number;
    };
  };
  version?: number;
  previousVersionId?: string;
}

export interface User {
  username: string;
  password: string;
  role: 'admin' | 'user';
  aadhaar?: string;
  phone?: string;
  biometricId?: string;
  email?: string;
  createdAt: string;
  lastLogin?: string;
  location?: {
    address: string;
    coordinates?: {
      latitude: number;
      longitude: number;
    };
  };
}

export interface UserActivity {
  id: string;
  username: string;
  action: 'login' | 'logout' | 'signup' | 'update_document';
  timestamp: string;
  details?: string;
}

export interface Block {
  blockNumber: number;
  timestamp: number;
  data: Document;
  previousHash: string;
  hash: string;
}

export interface BlockchainState {
  chain: Block[];
  pendingDocuments: Document[];
  addBlock: (document: Document) => Block;
  updateDocument: (documentId: string, updates: Partial<Document>) => Block;
  shareDocument: (documentId: string, recipient: string) => void;
  getPendingDocuments: () => Document[];
  getChain: () => Block[];
  getUserDocuments: (username: string) => Document[];
  searchDocuments: (query: string) => Document[];
  getDocumentById: (id: string) => Document | undefined;
  getDocumentHistory: (documentId: string) => Document[];
}

export interface EmailResponse {
  success: boolean;
  id?: string;
  threadId?: string;
  labelIds?: string[];
  error?: string;
}

export interface WhatsAppResponse {
  success: boolean;
  id?: string;
  status?: string;
  error?: string;
}