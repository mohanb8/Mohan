import React, { createContext, useContext, useState, useEffect } from 'react';
import SHA256 from 'crypto-js/sha256';
import { Document, Block, BlockchainState } from '../types';

const BlockchainContext = createContext<BlockchainState | undefined>(undefined);

export const useBlockchain = () => {
  const context = useContext(BlockchainContext);
  if (!context) {
    throw new Error('useBlockchain must be used within a BlockchainProvider');
  }
  return context;
};

const BLOCKCHAIN_STORAGE_KEY = 'blockchain_data';
const PENDING_DOCS_STORAGE_KEY = 'pending_documents';

export const BlockchainProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [chain, setChain] = useState<Block[]>(() => {
    const storedChain = localStorage.getItem(BLOCKCHAIN_STORAGE_KEY);
    if (storedChain) {
      return JSON.parse(storedChain);
    }
    
    // Create genesis block if no chain exists
    const genesisBlock: Block = {
      blockNumber: 0,
      timestamp: Date.now(),
      data: {
        id: 'genesis',
        title: 'Genesis Block',
        documentType: 'system',
        description: 'Initial block in the chain',
        parties: ['system'],
        uid: '0000000000',
        createdAt: new Date().toISOString(),
        hash: '',
        blockNumber: 0,
        previousHash: '0',
        owner: 'system',
        sharedWith: [],
        version: 1
      },
      previousHash: '0',
      hash: '0000000000000000000000000000000000000000000000000000000000000000'
    };
    
    return [genesisBlock];
  });
  
  const [pendingDocuments, setPendingDocuments] = useState<Document[]>(() => {
    const storedPendingDocs = localStorage.getItem(PENDING_DOCS_STORAGE_KEY);
    return storedPendingDocs ? JSON.parse(storedPendingDocs) : [];
  });

  useEffect(() => {
    localStorage.setItem(BLOCKCHAIN_STORAGE_KEY, JSON.stringify(chain));
  }, [chain]);

  useEffect(() => {
    localStorage.setItem(PENDING_DOCS_STORAGE_KEY, JSON.stringify(pendingDocuments));
  }, [pendingDocuments]);

  const calculateHash = (block: Omit<Block, 'hash'>): string => {
    return SHA256(
      block.blockNumber +
      block.timestamp +
      JSON.stringify(block.data) +
      block.previousHash
    ).toString();
  };

  const addBlock = (document: Document) => {
    const lastBlock = chain[chain.length - 1];
    const newBlockNumber = lastBlock.blockNumber + 1;
    
    const newBlock: Block = {
      blockNumber: newBlockNumber,
      timestamp: Date.now(),
      data: {
        ...document,
        blockNumber: newBlockNumber,
        hash: '',
        previousHash: lastBlock.hash,
        sharedWith: document.sharedWith || [],
        version: 1
      },
      previousHash: lastBlock.hash,
      hash: ''
    };
    
    // Calculate hash after setting all other properties
    newBlock.hash = calculateHash(newBlock);
    newBlock.data.hash = newBlock.hash;
    
    setChain(prevChain => [...prevChain, newBlock]);
    
    // Remove from pending if it was there
    setPendingDocuments(prevDocs => 
      prevDocs.filter(doc => doc.id !== document.id)
    );
    
    return newBlock;
  };

  const updateDocument = (documentId: string, updates: Partial<Document>) => {
    const existingDoc = chain.find(block => block.data.id === documentId)?.data;
    
    if (!existingDoc) {
      throw new Error('Document not found');
    }
    
    const lastBlock = chain[chain.length - 1];
    const newBlockNumber = lastBlock.blockNumber + 1;
    
    // Create a new document version that inherits all properties from the existing document
    const updatedDocument: Document = {
      ...existingDoc,
      ...updates,
      id: crypto.randomUUID(), // New ID for the updated version
      previousVersionId: documentId, // Link to previous version
      version: (existingDoc.version || 1) + 1,
      updatedAt: new Date().toISOString(),
      blockNumber: newBlockNumber,
      hash: '',
      previousHash: lastBlock.hash
    };
    
    const newBlock: Block = {
      blockNumber: newBlockNumber,
      timestamp: Date.now(),
      data: updatedDocument,
      previousHash: lastBlock.hash,
      hash: ''
    };
    
    // Calculate hash after setting all other properties
    newBlock.hash = calculateHash(newBlock);
    newBlock.data.hash = newBlock.hash;
    
    setChain(prevChain => [...prevChain, newBlock]);
    
    return newBlock;
  };

  const shareDocument = (documentId: string, recipient: string) => {
    const document = chain.find(block => block.data.id === documentId)?.data;
    
    if (!document) {
      throw new Error('Document not found');
    }
    
    // Create a new version with updated sharing information
    const updatedDocument: Document = {
      ...document,
      sharedWith: [...(document.sharedWith || []), recipient]
    };
    
    return updateDocument(documentId, updatedDocument);
  };

  const getPendingDocuments = () => {
    return pendingDocuments;
  };

  const getChain = () => {
    return chain;
  };

  const getUserDocuments = (username: string): Document[] => {
    // Get all documents for the user (including all versions)
    const allDocs = chain
      .filter(block => block.blockNumber > 0) // Skip genesis block
      .map(block => block.data)
      .filter(doc => doc.owner === username || (doc.sharedWith && doc.sharedWith.includes(username)));
    
    // Group documents by their original ID (first version) or current ID if no previous version
    const groupedDocs = allDocs.reduce((acc, doc) => {
      const originalId = doc.previousVersionId || doc.id;
      if (!acc[originalId] || (doc.version && acc[originalId].version && doc.version > acc[originalId].version)) {
        acc[originalId] = doc;
      }
      return acc;
    }, {} as Record<string, Document>);
    
    // Return only the latest version of each document
    return Object.values(groupedDocs);
  };

  const getDocumentHistory = (documentId: string): Document[] => {
    const history: Document[] = [];
    let currentDoc = chain.find(block => block.data.id === documentId)?.data;
    
    while (currentDoc) {
      history.push(currentDoc);
      currentDoc = currentDoc.previousVersionId
        ? chain.find(block => block.data.id === currentDoc?.previousVersionId)?.data
        : null;
    }
    
    return history.reverse(); // Return in chronological order
  };

  const searchDocuments = (query: string): Document[] => {
    if (!query.trim()) return [];
    
    const lowerCaseQuery = query.toLowerCase();
    
    // Get all documents (including all versions)
    const allDocs = chain
      .filter(block => block.blockNumber > 0) // Skip genesis block
      .map(block => block.data)
      .filter(doc => 
        doc.title.toLowerCase().includes(lowerCaseQuery) ||
        doc.description.toLowerCase().includes(lowerCaseQuery) ||
        doc.uid.toLowerCase().includes(lowerCaseQuery) ||
        doc.parties.some(party => party.toLowerCase().includes(lowerCaseQuery)) ||
        doc.documentType.toLowerCase().includes(lowerCaseQuery)
      );
    
    // Group documents by their original ID (first version) or current ID if no previous version
    const groupedDocs = allDocs.reduce((acc, doc) => {
      const originalId = doc.previousVersionId || doc.id;
      if (!acc[originalId] || (doc.version && acc[originalId].version && doc.version > acc[originalId].version)) {
        acc[originalId] = doc;
      }
      return acc;
    }, {} as Record<string, Document>);
    
    // Return only the latest version of each document
    return Object.values(groupedDocs);
  };

  const getDocumentById = (id: string): Document | undefined => {
    const block = chain.find(block => block.data.id === id);
    return block?.data;
  };

  const value: BlockchainState = {
    chain,
    pendingDocuments,
    addBlock,
    updateDocument,
    shareDocument,
    getPendingDocuments,
    getChain,
    getUserDocuments,
    searchDocuments,
    getDocumentById,
    getDocumentHistory
  };

  return (
    <BlockchainContext.Provider value={value}>
      {children}
    </BlockchainContext.Provider>
  );
};