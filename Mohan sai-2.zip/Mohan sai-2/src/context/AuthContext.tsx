import React, { createContext, useContext, useState, useEffect } from 'react';
import { User, AuthState, UserActivity } from '../types';

const AuthContext = createContext<AuthState | undefined>(undefined);

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};

// Initial admin user
const INITIAL_USERS: User[] = [
  { 
    username: 'admin', 
    password: 'admin', 
    role: 'admin',
    aadhaar: '123456789012',
    phone: '+91-9876543210',
    biometricId: 'admin-bio-123',
    email: 'admin@example.com',
    createdAt: new Date('2024-01-01').toISOString(),
    lastLogin: new Date().toISOString(),
    location: {
      address: 'Admin Office, Tech Park',
      coordinates: {
        latitude: 12.9716,
        longitude: 77.5946
      }
    }
  }
];

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [users, setUsers] = useState<User[]>(() => {
    const storedUsers = localStorage.getItem('auth_users');
    return storedUsers ? JSON.parse(storedUsers) : INITIAL_USERS;
  });

  const [userActivities, setUserActivities] = useState<UserActivity[]>(() => {
    const storedActivities = localStorage.getItem('user_activities');
    return storedActivities ? JSON.parse(storedActivities) : [];
  });

  const [user, setUser] = useState<User | null>(() => {
    const storedUser = localStorage.getItem('auth_user');
    return storedUser ? JSON.parse(storedUser) : null;
  });
  
  const [currentAuthStep, setCurrentAuthStep] = useState<'credentials' | 'aadhaar' | 'biometric' | 'complete'>(
    () => {
      const storedStep = localStorage.getItem('auth_step');
      return user ? (storedStep as any || 'complete') : 'credentials';
    }
  );
  
  const [tempUserData, setTempUserData] = useState<User | null>(null);

  useEffect(() => {
    localStorage.setItem('auth_users', JSON.stringify(users));
  }, [users]);

  useEffect(() => {
    localStorage.setItem('user_activities', JSON.stringify(userActivities));
  }, [userActivities]);

  useEffect(() => {
    if (user && currentAuthStep === 'complete') {
      localStorage.setItem('auth_user', JSON.stringify(user));
      localStorage.setItem('auth_step', 'complete');
    } else if (!user) {
      localStorage.removeItem('auth_user');
      localStorage.removeItem('auth_step');
    } else {
      localStorage.setItem('auth_step', currentAuthStep);
    }
  }, [user, currentAuthStep]);

  const addUserActivity = (activity: Omit<UserActivity, 'id' | 'timestamp'>) => {
    const newActivity: UserActivity = {
      id: crypto.randomUUID(),
      timestamp: new Date().toISOString(),
      ...activity
    };
    setUserActivities(prev => [newActivity, ...prev]);
  };

  const login = (username: string, password: string): boolean => {
    const foundUser = users.find(
      u => u.username === username && u.password === password
    );
    
    if (foundUser) {
      setTempUserData(foundUser);
      setCurrentAuthStep('aadhaar');
      return true;
    }
    
    return false;
  };

  const signup = (userData: Omit<User, 'createdAt'>): boolean => {
    // Check if username already exists
    if (users.some(u => u.username === userData.username)) {
      return false;
    }

    const newUser: User = {
      ...userData,
      createdAt: new Date().toISOString()
    };

    setUsers(prev => [...prev, newUser]);
    addUserActivity({
      username: newUser.username,
      action: 'signup',
      details: `New ${newUser.role} account created`
    });

    return true;
  };
  
  const verifyAadhaar = (aadhaar: string, otp: string): boolean => {
    if (!tempUserData) return false;
    
    // In a real app, you would verify the OTP with an SMS service
    // For demo purposes, we'll accept any 6-digit OTP
    const isValidOtp = /^\d{6}$/.test(otp);
    
    // Check if the Aadhaar number matches the one associated with the user
    const isValidAadhaar = tempUserData.aadhaar === aadhaar;
    
    if (isValidOtp && isValidAadhaar) {
      setCurrentAuthStep('biometric');
      return true;
    }
    
    return false;
  };
  
  const verifyBiometric = (biometricData: string): boolean => {
    if (!tempUserData) return false;
    
    // In a real app, you would verify the biometric data with a biometric service
    // For demo purposes, we'll accept any non-empty string
    if (biometricData && biometricData.length > 0) {
      const updatedUser = {
        ...tempUserData,
        lastLogin: new Date().toISOString()
      };
      setUser(updatedUser);
      setUsers(prev => prev.map(u => 
        u.username === updatedUser.username ? updatedUser : u
      ));
      setCurrentAuthStep('complete');
      setTempUserData(null);

      addUserActivity({
        username: updatedUser.username,
        action: 'login',
        details: `Logged in successfully`
      });

      return true;
    }
    
    return false;
  };

  const logout = () => {
    if (user) {
      addUserActivity({
        username: user.username,
        action: 'logout',
        details: 'User logged out'
      });
    }
    setUser(null);
    setCurrentAuthStep('credentials');
    setTempUserData(null);
  };

  const getAllUsers = () => {
    return users;
  };

  const getUserActivities = () => {
    return userActivities;
  };

  const value: AuthState = {
    user,
    users,
    userActivities,
    isAuthenticated: !!user && currentAuthStep === 'complete',
    currentAuthStep,
    login,
    signup,
    verifyAadhaar,
    verifyBiometric,
    logout,
    getAllUsers,
    getUserActivities
  };

  return (
    <AuthContext.Provider value={value}>
      {children}
    </AuthContext.Provider>
  );
};