import React, { useState } from 'react';
import { X, Mail, Phone, Loader } from 'lucide-react';
import { sendEmail } from '../services/gmail';
import { sendWhatsAppMessage } from '../services/whatsapp';

interface ShareModalProps {
  documentTitle: string;
  documentUrl?: string;
  documentPath?: string;
  onClose: () => void;
  onShare: (recipient: string, method: 'email' | 'whatsapp') => void;
}

const ShareModal: React.FC<ShareModalProps> = ({ 
  documentTitle, 
  documentUrl,
  documentPath,
  onClose, 
  onShare 
}) => {
  const [recipient, setRecipient] = useState('');
  const [method, setMethod] = useState<'email' | 'whatsapp'>('email');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');
  
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setSuccess('');
    
    if (!recipient) {
      setError('Please enter a recipient');
      return;
    }
    
    if (method === 'email' && !recipient.includes('@')) {
      setError('Please enter a valid email address');
      return;
    }
    
    if (method === 'whatsapp' && !/^\+?[0-9]{10,15}$/.test(recipient)) {
      setError('Please enter a valid phone number');
      return;
    }
    
    setIsSubmitting(true);
    
    try {
      if (method === 'email') {
        const subject = `Shared Document: ${documentTitle}`;
        const body = `
          A document has been shared with you from the E-Vault system.
          
          Document: ${documentTitle}
          ${documentUrl ? `View online: ${documentUrl}` : ''}
          
          This is a secure document share. Please handle this information with care.
        `;
        
        await sendEmail(recipient, subject, body, documentPath);
        setSuccess('Document has been sent via email successfully!');
      } else {
        const message = `
          *Shared Document: ${documentTitle}*
          
          A document has been shared with you from the E-Vault system.
          ${documentUrl ? `\nView online: ${documentUrl}` : ''}
          
          This is a secure document share. Please handle this information with care.
        `;
        
        await sendWhatsAppMessage(recipient, message, documentUrl);
        setSuccess('Document has been sent via WhatsApp successfully!');
      }
      
      onShare(recipient, method);
      
      // Close modal after success
      setTimeout(() => {
        onClose();
      }, 2000);
    } catch (err) {
      console.error('Error sharing document:', err);
      setError(`Failed to send document via ${method}. Please try again.`);
    } finally {
      setIsSubmitting(false);
    }
  };
  
  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-lg shadow-xl max-w-md w-full">
        <div className="flex justify-between items-center border-b border-gray-200 px-6 py-4">
          <h3 className="text-lg font-semibold">Share Document</h3>
          <button onClick={onClose} className="text-gray-400 hover:text-gray-500">
            <X className="h-5 w-5" />
          </button>
        </div>
        
        <form onSubmit={handleSubmit} className="p-6">
          <div className="mb-4">
            <p className="text-gray-600 mb-2">
              Share "{documentTitle}" with others
            </p>
          </div>
          
          {error && (
            <div className="mb-4 bg-red-50 border-l-4 border-red-500 p-3">
              <p className="text-sm text-red-700">{error}</p>
            </div>
          )}

          {success && (
            <div className="mb-4 bg-green-50 border-l-4 border-green-500 p-3">
              <p className="text-sm text-green-700">{success}</p>
            </div>
          )}
          
          <div className="mb-4">
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Share via
            </label>
            <div className="flex space-x-4">
              <button
                type="button"
                onClick={() => setMethod('email')}
                className={`flex items-center px-4 py-2 rounded-md ${
                  method === 'email' 
                    ? 'bg-blue-100 text-blue-700 border border-blue-300'
                    : 'bg-gray-100 text-gray-700 border border-gray-300'
                }`}
              >
                <Mail className="h-4 w-4 mr-2" />
                Email
              </button>
              <button
                type="button"
                onClick={() => setMethod('whatsapp')}
                className={`flex items-center px-4 py-2 rounded-md ${
                  method === 'whatsapp' 
                    ? 'bg-green-100 text-green-700 border border-green-300'
                    : 'bg-gray-100 text-gray-700 border border-gray-300'
                }`}
              >
                <Phone className="h-4 w-4 mr-2" />
                WhatsApp
              </button>
            </div>
          </div>
          
          <div className="mb-6">
            <label htmlFor="recipient" className="block text-sm font-medium text-gray-700 mb-1">
              {method === 'email' ? 'Email Address' : 'Phone Number'}
            </label>
            <input
              type={method === 'email' ? 'email' : 'tel'}
              id="recipient"
              value={recipient}
              onChange={(e) => setRecipient(e.target.value)}
              className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-blue-500 focus:border-blue-500"
              placeholder={method === 'email' ? 'example@email.com' : '+91 98765 43210'}
            />
          </div>
          
          <div className="flex justify-end space-x-3">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 border border-gray-300 rounded-md text-sm font-medium text-gray-700 bg-white hover:bg-gray-50"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={isSubmitting}
              className={`px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 ${
                isSubmitting ? 'opacity-70 cursor-not-allowed' : ''
              }`}
            >
              {isSubmitting ? (
                <span className="flex items-center">
                  <Loader className="animate-spin h-4 w-4 mr-2" />
                  Sending...
                </span>
              ) : (
                'Share'
              )}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default ShareModal;