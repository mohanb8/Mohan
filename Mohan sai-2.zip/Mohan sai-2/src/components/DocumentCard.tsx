import React, { useState } from 'react';
import { FileText, Download, Calendar, User, Hash, Database, MapPin, ChevronDown, ChevronUp, Edit, History } from 'lucide-react';
import { Document } from '../types';
import { useAuth } from '../context/AuthContext';

interface DocumentCardProps {
  document: Document;
  showDownload?: boolean;
  onEdit?: (document: Document) => void;
  onViewHistory?: (document: Document) => void;
}

const DocumentCard: React.FC<DocumentCardProps> = ({ 
  document, 
  showDownload = false, 
  onEdit,
  onViewHistory
}) => {
  const { user } = useAuth();
  const isAdmin = user?.role === 'admin';
  const isOwner = user?.username === document.owner;
  const [isExpanded, setIsExpanded] = useState(false);
  
  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'long',
      day: 'numeric'
    });
  };

  return (
    <div className="bg-white rounded-lg shadow-md overflow-hidden border border-gray-200">
      <div className="bg-blue-700 text-white py-3 px-4 flex items-center justify-between">
        <div className="flex items-center space-x-2">
          <FileText className="h-5 w-5" />
          <h3 className="font-semibold text-lg">{document.title}</h3>
        </div>
        <div className="flex items-center space-x-2">
          <span className="text-sm bg-blue-800 px-2 py-1 rounded">
            {document.documentType}
          </span>
          {(isAdmin || isOwner) && onEdit && (
            <button
              onClick={() => onEdit(document)}
              className="p-1 hover:bg-blue-600 rounded"
              title="Edit document"
            >
              <Edit className="h-4 w-4" />
            </button>
          )}
          {(isAdmin || isOwner) && onViewHistory && (
            <button
              onClick={() => onViewHistory(document)}
              className="p-1 hover:bg-blue-600 rounded"
              title="View document history"
            >
              <History className="h-4 w-4" />
            </button>
          )}
        </div>
      </div>
      
      <div className="p-4">
        <div className="mb-4">
          <div className={`text-gray-600 ${!isExpanded ? 'line-clamp-2' : ''}`}>
            {document.description}
          </div>
          {document.description.length > 100 && (
            <button
              onClick={() => setIsExpanded(!isExpanded)}
              className="mt-2 text-blue-600 hover:text-blue-800 text-sm flex items-center"
            >
              {isExpanded ? (
                <>
                  Show less
                  <ChevronUp className="h-4 w-4 ml-1" />
                </>
              ) : (
                <>
                  Show more
                  <ChevronDown className="h-4 w-4 ml-1" />
                </>
              )}
            </button>
          )}
        </div>
        
        <div className="space-y-2 text-sm">
          <div className="flex items-center space-x-2">
            <User className="h-4 w-4 text-gray-500" />
            <span className="text-gray-700">Parties: {document.parties.join(', ')}</span>
          </div>
          
          <div className="flex items-center space-x-2">
            <Calendar className="h-4 w-4 text-gray-500" />
            <span className="text-gray-700">Created: {formatDate(document.createdAt)}</span>
          </div>

          {document.updatedAt && (
            <div className="flex items-center space-x-2">
              <Calendar className="h-4 w-4 text-gray-500" />
              <span className="text-gray-700">Updated: {formatDate(document.updatedAt)}</span>
            </div>
          )}
          
          <div className="flex items-center space-x-2">
            <Database className="h-4 w-4 text-gray-500" />
            <span className="text-gray-700">UID: {document.uid}</span>
          </div>
          
          <div className="flex items-center space-x-2">
            <Hash className="h-4 w-4 text-gray-500" />
            <span className="text-gray-700 truncate" title={document.hash}>
              Hash: {document.hash.substring(0, 16)}...
            </span>
          </div>
          
          <div className="flex items-center space-x-2">
            <Database className="h-4 w-4 text-gray-500" />
            <span className="text-gray-700">Block: #{document.blockNumber}</span>
          </div>

          {document.version && (
            <div className="flex items-center space-x-2">
              <Database className="h-4 w-4 text-gray-500" />
              <span className="text-gray-700">Version: {document.version}</span>
            </div>
          )}
          
          {document.owner && (
            <div className="flex items-center space-x-2">
              <User className="h-4 w-4 text-gray-500" />
              <span className="text-gray-700">Owner: {document.owner}</span>
            </div>
          )}

          {document.location && (
            <div className="flex items-center space-x-2">
              <MapPin className="h-4 w-4 text-gray-500" />
              <span className="text-gray-700">Location: {document.location.address}</span>
            </div>
          )}
        </div>
        
        {(showDownload && (isAdmin || isOwner) && document.fileUrl) && (
          <div className="mt-4 pt-3 border-t border-gray-200">
            <a 
              href={document.fileUrl}
              download
              className="flex items-center space-x-2 text-blue-600 hover:text-blue-800"
            >
              <Download className="h-4 w-4" />
              <span>Download Document</span>
            </a>
          </div>
        )}
      </div>
    </div>
  );
};

export default DocumentCard;