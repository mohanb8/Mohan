import React from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { Database, LogOut, FileText, Upload, User } from 'lucide-react';
import { useAuth } from '../context/AuthContext';

const Navbar: React.FC = () => {
  const { user, logout } = useAuth();
  const navigate = useNavigate();

  const handleLogout = () => {
    logout();
    navigate('/');
  };

  return (
    <nav className="bg-blue-800 text-white shadow-md">
      <div className="container mx-auto px-4 py-3">
        <div className="flex justify-between items-center">
          <Link to="/" className="flex items-center space-x-2">
            <Database className="h-6 w-6" />
            <span className="text-xl font-bold">E-Vault</span>
          </Link>
          
          <div className="flex items-center space-x-6">
            {user ? (
              <>
                <span className="text-sm">
                  Welcome, <span className="font-semibold">{user.username}</span> ({user.role})
                </span>
                
                {user.role === 'admin' && (
                  <>
                    <Link to="/admin/add-document" className="hover:text-blue-200 flex items-center space-x-1">
                      <FileText className="h-4 w-4" />
                      <span>Add Document</span>
                    </Link>
                    <Link to="/admin/view-documents" className="hover:text-blue-200 flex items-center space-x-1">
                      <FileText className="h-4 w-4" />
                      <span>View Documents</span>
                    </Link>
                  </>
                )}
                
                {user.role === 'user' && (
                  <Link to="/user/documents" className="hover:text-blue-200 flex items-center space-x-1">
                    <User className="h-4 w-4" />
                    <span>My Documents</span>
                  </Link>
                )}
                
                <button 
                  onClick={handleLogout}
                  className="flex items-center space-x-1 hover:text-blue-200"
                >
                  <LogOut className="h-4 w-4" />
                  <span>Logout</span>
                </button>
              </>
            ) : (
              <>
                <Link to="/login" className="hover:text-blue-200">Login</Link>
                <Link to="/search" className="hover:text-blue-200">Search Documents</Link>
              </>
            )}
          </div>
        </div>
      </div>
    </nav>
  );
};

export default Navbar;