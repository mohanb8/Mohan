import React from 'react';
import { X, History, Calendar, User, Hash, Database, MapPin } from 'lucide-react';
import { Document } from '../types';

interface DocumentHistoryModalProps {
  document: Document;
  history: Document[];
  onClose: () => void;
}

const DocumentHistoryModal: React.FC<DocumentHistoryModalProps> = ({ document, history, onClose }) => {
  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleString('en-US', {
      year: 'numeric',
      month: 'long',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-lg shadow-xl max-w-4xl w-full max-h-[90vh] overflow-y-auto">
        <div className="flex justify-between items-center border-b border-gray-200 px-6 py-4">
          <div>
            <h3 className="text-lg font-semibold flex items-center">
              <History className="h-5 w-5 mr-2" />
              Document Version History
            </h3>
            <p className="text-sm text-gray-500 mt-1">
              Viewing history for "{document.title}"
            </p>
          </div>
          <button onClick={onClose} className="text-gray-400 hover:text-gray-500">
            <X className="h-5 w-5" />
          </button>
        </div>
        
        <div className="p-6">
          <div className="space-y-8">
            {history.map((version, index) => (
              <div 
                key={version.id}
                className={`relative pb-8 ${
                  index < history.length - 1 ? 'border-l-2 border-gray-200' : ''
                }`}
              >
                <div className="relative flex items-start">
                  <div className="absolute -left-[9px] bg-white">
                    <div className={`w-4 h-4 rounded-full border-2 ${
                      index === 0 ? 'border-blue-500 bg-blue-50' : 'border-gray-400 bg-white'
                    }`} />
                  </div>
                  
                  <div className="ml-6">
                    <div className="flex items-center">
                      <span className={`text-sm font-medium ${
                        index === 0 ? 'text-blue-600' : 'text-gray-900'
                      }`}>
                        Version {version.version}
                      </span>
                      {index === 0 && (
                        <span className="ml-2 px-2 py-0.5 text-xs font-medium bg-blue-100 text-blue-800 rounded-full">
                          Latest
                        </span>
                      )}
                    </div>
                    
                    <div className="mt-2 bg-gray-50 rounded-lg p-4">
                      <div className="grid grid-cols-2 gap-4">
                        <div>
                          <h4 className="text-sm font-medium text-gray-900">Document Details</h4>
                          <div className="mt-2 space-y-2 text-sm">
                            <p><span className="font-medium">Title:</span> {version.title}</p>
                            <p><span className="font-medium">Type:</span> {version.documentType}</p>
                            <p><span className="font-medium">UID:</span> {version.uid}</p>
                            <p><span className="font-medium">Parties:</span> {version.parties.join(', ')}</p>
                            <p className="whitespace-pre-wrap">
                              <span className="font-medium">Description:</span> {version.description}
                            </p>
                          </div>
                        </div>
                        
                        <div>
                          <h4 className="text-sm font-medium text-gray-900">Metadata</h4>
                          <div className="mt-2 space-y-2 text-sm">
                            <div className="flex items-center">
                              <Calendar className="h-4 w-4 text-gray-500 mr-2" />
                              <span>
                                {version.updatedAt 
                                  ? `Updated: ${formatDate(version.updatedAt)}`
                                  : `Created: ${formatDate(version.createdAt)}`
                                }
                              </span>
                            </div>
                            
                            <div className="flex items-center">
                              <User className="h-4 w-4 text-gray-500 mr-2" />
                              <span>Owner: {version.owner}</span>
                            </div>
                            
                            <div className="flex items-center">
                              <Hash className="h-4 w-4 text-gray-500 mr-2" />
                              <span className="truncate" title={version.hash}>
                                Hash: {version.hash.substring(0, 16)}...
                              </span>
                            </div>
                            
                            <div className="flex items-center">
                              <Database className="h-4 w-4 text-gray-500 mr-2" />
                              <span>Block: #{version.blockNumber}</span>
                            </div>
                            
                            {version.location && (
                              <div className="flex items-center">
                                <MapPin className="h-4 w-4 text-gray-500 mr-2" />
                                <span>Location: {version.location.address}</span>
                              </div>
                            )}
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

export default DocumentHistoryModal;