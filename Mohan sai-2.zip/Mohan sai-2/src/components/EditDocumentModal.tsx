import React, { useState } from 'react';
import { X, Save, MapPin } from 'lucide-react';
import { Document } from '../types';

interface EditDocumentModalProps {
  document: Document;
  onClose: () => void;
  onSave: (updates: Partial<Document>) => void;
}

const EditDocumentModal: React.FC<EditDocumentModalProps> = ({ document, onClose, onSave }) => {
  const [title, setTitle] = useState(document.title);
  const [documentType, setDocumentType] = useState(document.documentType);
  const [description, setDescription] = useState(document.description);
  const [parties, setParties] = useState(document.parties.join(', '));
  const [uid, setUid] = useState(document.uid);
  const [file, setFile] = useState<File | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [error, setError] = useState('');
  
  // Location state
  const [location, setLocation] = useState<{ address: string; coordinates?: { latitude: number; longitude: number } } | null>(
    document.location || null
  );
  const [isLoadingLocation, setIsLoadingLocation] = useState(false);

  const getLocation = () => {
    setIsLoadingLocation(true);
    if ("geolocation" in navigator) {
      navigator.geolocation.getCurrentPosition(
        position => {
          const { latitude, longitude } = position.coords;
          fetch(`https://api.opencagedata.com/geocode/v1/json?q=${latitude}+${longitude}&key=282d06b4edd240b4afbbd5202830fd3e`)
            .then(response => response.json())
            .then(data => {
              if (data.results && data.results[0]) {
                setLocation({
                  address: data.results[0].formatted,
                  coordinates: { latitude, longitude }
                });
              }
            })
            .catch(error => {
              console.error('Error getting location:', error);
              setError('Failed to get location. Please try again.');
            })
            .finally(() => setIsLoadingLocation(false));
        },
        error => {
          console.error('Error getting location:', error);
          setError('Location access denied. Please enable location services.');
          setIsLoadingLocation(false);
        }
      );
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    
    if (!title || !documentType || !description || !parties || !uid) {
      setError('Please fill in all required fields');
      return;
    }
    
    setIsSubmitting(true);
    
    try {
      const updates: Partial<Document> = {
        title,
        documentType,
        description,
        parties: parties.split(',').map(p => p.trim()),
        uid,
        location
      };
      
      if (file) {
        updates.fileUrl = URL.createObjectURL(file);
      }
      
      onSave(updates);
    } catch (error) {
      console.error('Error updating document:', error);
      setError('Failed to update document. Please try again.');
      setIsSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-lg shadow-xl max-w-2xl w-full max-h-[90vh] overflow-y-auto">
        <div className="flex justify-between items-center border-b border-gray-200 px-6 py-4">
          <h3 className="text-lg font-semibold">Edit Document</h3>
          <button onClick={onClose} className="text-gray-400 hover:text-gray-500">
            <X className="h-5 w-5" />
          </button>
        </div>
        
        <form onSubmit={handleSubmit} className="p-6">
          {error && (
            <div className="mb-4 bg-red-50 border-l-4 border-red-500 p-4">
              <p className="text-sm text-red-700">{error}</p>
            </div>
          )}
          
          <div className="space-y-4">
            <div>
              <label htmlFor="title" className="block text-sm font-medium text-gray-700 mb-1">
                Document Title
              </label>
              <input
                type="text"
                id="title"
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-blue-500 focus:border-blue-500"
                required
              />
            </div>
            
            <div>
              <label htmlFor="documentType" className="block text-sm font-medium text-gray-700 mb-1">
                Document Type
              </label>
              <select
                id="documentType"
                value={documentType}
                onChange={(e) => setDocumentType(e.target.value)}
                className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-blue-500 focus:border-blue-500"
                required
              >
                <option value="">Select a type</option>
                <option value="Rent Agreement">Rent Agreement</option>
                <option value="Property Deed">Property Deed</option>
                <option value="Will">Will</option>
                <option value="Power of Attorney">Power of Attorney</option>
                <option value="Court Order">Court Order</option>
                <option value="Contract">Contract</option>
                <option value="Other">Other</option>
              </select>
            </div>
            
            <div>
              <label htmlFor="uid" className="block text-sm font-medium text-gray-700 mb-1">
                UID Number
              </label>
              <input
                type="text"
                id="uid"
                value={uid}
                onChange={(e) => setUid(e.target.value)}
                className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-blue-500 focus:border-blue-500"
                required
              />
            </div>
            
            <div>
              <label htmlFor="parties" className="block text-sm font-medium text-gray-700 mb-1">
                Parties Involved (comma separated)
              </label>
              <input
                type="text"
                id="parties"
                value={parties}
                onChange={(e) => setParties(e.target.value)}
                className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-blue-500 focus:border-blue-500"
                placeholder="e.g. John Doe, Jane Smith"
                required
              />
            </div>
            
            <div>
              <label htmlFor="description" className="block text-sm font-medium text-gray-700 mb-1">
                Description
              </label>
              <textarea
                id="description"
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                rows={4}
                className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-blue-500 focus:border-blue-500"
                required
              ></textarea>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Document Location
              </label>
              <div className="flex items-center space-x-2 p-3 bg-gray-50 rounded-md">
                <MapPin className="h-5 w-5 text-gray-500" />
                <span className="text-gray-700">
                  {isLoadingLocation ? (
                    'Fetching location...'
                  ) : location ? (
                    location.address
                  ) : (
                    'Location not available'
                  )}
                </span>
                {!isLoadingLocation && (
                  <button
                    type="button"
                    onClick={getLocation}
                    className="ml-2 text-blue-600 hover:text-blue-800 text-sm"
                  >
                    {location ? 'Update Location' : 'Get Location'}
                  </button>
                )}
              </div>
            </div>
            
            <div>
              <label htmlFor="file" className="block text-sm font-medium text-gray-700 mb-1">
                Update Document File (optional)
              </label>
              <input
                type="file"
                id="file"
                onChange={(e) => setFile(e.target.files?.[0] || null)}
                className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-blue-500 focus:border-blue-500"
              />
              {file && (
                <p className="mt-1 text-sm text-green-600">
                  Selected: {file.name}
                </p>
              )}
            </div>
          </div>
          
          <div className="mt-6 flex justify-end space-x-3">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 border border-gray-300 rounded-md text-sm font-medium text-gray-700 bg-white hover:bg-gray-50"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={isSubmitting}
              className={`flex items-center px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 ${
                isSubmitting ? 'opacity-70 cursor-not-allowed' : ''
              }`}
            >
              {isSubmitting ? (
                <>
                  <svg className="animate-spin -ml-1 mr-2 h-4 w-4 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                    <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                    <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                  </svg>
                  Saving...
                </>
              ) : (
                <>
                  <Save className="h-4 w-4 mr-2" />
                  Save Changes
                </>
              )}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default EditDocumentModal;