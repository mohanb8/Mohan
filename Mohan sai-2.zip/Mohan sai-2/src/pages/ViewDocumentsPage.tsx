import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Database, Share2, Users, Clock, LogOut, MapPin, Filter, History } from 'lucide-react';
import { useBlockchain } from '../context/BlockchainContext';
import { useAuth } from '../context/AuthContext';
import DocumentCard from '../components/DocumentCard';
import ShareModal from '../components/ShareModal';
import { Document } from '../types';

const ViewDocumentsPage: React.FC = () => {
  const { getChain } = useBlockchain();
  const { user, getAllUsers, getUserActivities } = useAuth();
  const navigate = useNavigate();
  
  // Sharing state
  const [showShareModal, setShowShareModal] = useState(false);
  const [selectedDocument, setSelectedDocument] = useState<Document | null>(null);
  
  // Tab state
  const [activeTab, setActiveTab] = useState<'documents' | 'users' | 'activity'>('documents');
  
  // User filter state
  const [selectedUser, setSelectedUser] = useState<string>('all');
  
  // Location state
  const [userLocation, setUserLocation] = useState<string>('');
  
  // Get user location on component mount
  React.useEffect(() => {
    if ("geolocation" in navigator) {
      navigator.geolocation.getCurrentPosition(
        position => {
          fetch(`https://api.opencagedata.com/geocode/v1/json?q=${position.coords.latitude}+${position.coords.longitude}&key=282d06b4edd240b4afbbd5202830fd3e`)
            .then(response => response.json())
            .then(data => {
              if (data.results && data.results[0]) {
                setUserLocation(data.results[0].formatted);
              }
            })
            .catch(() => setUserLocation('Location not available'));
        },
        () => setUserLocation('Location access denied')
      );
    }
  }, []);
  
  // Redirect if not admin
  if (user?.role !== 'admin') {
    navigate('/login');
    return null;
  }
  
  const chain = getChain();
  
  // Get all documents and group them by their original document ID
  const documents = chain
    .filter(block => block.blockNumber > 0) // Skip genesis block
    .map(block => block.data)
    .reduce((acc, doc) => {
      const originalId = doc.previousVersionId || doc.id;
      if (!acc[originalId] || (doc.version && acc[originalId].version && doc.version > acc[originalId].version)) {
        acc[originalId] = doc;
      }
      return acc;
    }, {} as Record<string, Document>);

  // Convert the grouped documents object back to an array
  const latestDocuments = Object.values(documents);

  // Filter documents by selected user
  const filteredDocuments = selectedUser === 'all' 
    ? latestDocuments 
    : latestDocuments.filter(doc => doc.owner === selectedUser);

  const users = getAllUsers();
  const activities = getUserActivities();

  const openShareModal = (document: Document) => {
    setSelectedDocument(document);
    setShowShareModal(true);
  };

  const handleShare = (recipient: string, method: 'email' | 'whatsapp') => {
    // In a real app, this would send the document via email or WhatsApp
    console.log(`Admin sharing document ${selectedDocument?.id} with ${recipient} via ${method}`);
    
    // Close modal after sharing
    setTimeout(() => {
      setShowShareModal(false);
      setSelectedDocument(null);
    }, 3000);
  };

  const handleViewHistory = (document: Document) => {
    navigate(`/document/${document.id}/history`);
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleString('en-US', {
      year: 'numeric',
      month: 'long',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
      second: '2-digit',
      timeZoneName: 'short'
    });
  };

  const handleAddDocument = () => {
    navigate('/admin/add-document');
  };

  const handleAddDocuments = () => {
    navigate('/user/documents');
  };

  // Get document count by user (using latest versions only)
  const getDocumentCountByUser = (username: string) => {
    return latestDocuments.filter(doc => doc.owner === username).length;
  };
  
  return (
    <div className="container mx-auto px-4 py-8">
      <div className="mb-8">
        <div className="flex justify-between items-center mb-6">
          <h1 className="text-2xl font-bold flex items-center">
            <Database className="mr-2 h-6 w-6" />
            Admin Dashboard
          </h1>
          <div className="flex items-center text-sm text-gray-600">
            <MapPin className="h-4 w-4 mr-1" />
            <span>{userLocation || 'Fetching location...'}</span>
            <span className="mx-2">•</span>
            <Clock className="h-4 w-4 mr-1" />
            <span>{new Date().toLocaleString()}</span>
          </div>
        </div>

        <div className="border-b border-gray-200">
          <nav className="-mb-px flex space-x-8">
            <button
              onClick={() => setActiveTab('documents')}
              className={`${
                activeTab === 'documents'
                  ? 'border-blue-500 text-blue-600'
                  : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
              } whitespace-nowrap py-4 px-1 border-b-2 font-medium text-sm flex items-center`}
            >
              <Database className="h-5 w-5 mr-2" />
              Documents ({latestDocuments.length})
            </button>

            <button
              onClick={() => setActiveTab('users')}
              className={`${
                activeTab === 'users'
                  ? 'border-blue-500 text-blue-600'
                  : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
              } whitespace-nowrap py-4 px-1 border-b-2 font-medium text-sm flex items-center`}
            >
              <Users className="h-5 w-5 mr-2" />
              Users ({users.length})
            </button>

            <button
              onClick={() => setActiveTab('activity')}
              className={`${
                activeTab === 'activity'
                  ? 'border-blue-500 text-blue-600'
                  : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
              } whitespace-nowrap py-4 px-1 border-b-2 font-medium text-sm flex items-center`}
            >
              <Clock className="h-5 w-5 mr-2" />
              Activity Log
            </button>
          </nav>
        </div>
      </div>
      
      {/* Documents Tab */}
      {activeTab === 'documents' && (
        <div>
          <div className="flex justify-between items-center mb-6">
            <div className="flex items-center space-x-4">
              <h2 className="text-xl font-semibold">All Documents</h2>
              <div className="flex items-center space-x-2">
                <Filter className="h-4 w-4 text-gray-500" />
                <select
                  value={selectedUser}
                  onChange={(e) => setSelectedUser(e.target.value)}
                  className="border border-gray-300 rounded-md text-sm py-1 px-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
                >
                  <option value="all">All Users</option>
                  {users.map(u => (
                    <option key={u.username} value={u.username}>
                      {u.username} ({getDocumentCountByUser(u.username)} documents)
                    </option>
                  ))}
                </select>
              </div>
            </div>
            <button
              onClick={handleAddDocuments}
              className="bg-blue-600 text-white px-4 py-2 rounded-md hover:bg-blue-700 flex items-center"
            >
              <Database className="h-4 w-4 mr-2" />
              Add New Document
            </button>
          </div>

          {filteredDocuments.length === 0 ? (
            <div className="bg-white rounded-lg shadow-md p-8 text-center">
              <p className="text-gray-500 mb-4">
                {selectedUser === 'all' 
                  ? 'No documents have been added to the blockchain yet.'
                  : `No documents found for user "${selectedUser}".`}
              </p>
              <button
                onClick={handleAddDocument}
                className="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md shadow-sm text-white bg-blue-600 hover:bg-blue-700"
              >
                Add Your First Document
              </button>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {filteredDocuments.map(doc => (
                <div key={doc.id} className="border border-gray-200 rounded-lg overflow-hidden">
                  <DocumentCard 
                    document={doc} 
                    showDownload={true}
                    onViewHistory={handleViewHistory}
                  />
                  <div className="p-4 bg-gray-50 border-t border-gray-200">
                    <button
                      onClick={() => openShareModal(doc)}
                      className="flex items-center text-blue-600 hover:text-blue-800"
                    >
                      <Share2 className="h-4 w-4 mr-2" />
                      Share Document
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* Users Tab */}
      {activeTab === 'users' && (
        <div>
          <div className="bg-white shadow-md rounded-lg overflow-hidden">
            <table className="min-w-full divide-y divide-gray-200">
              <thead className="bg-gray-50">
                <tr>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Username
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Role
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Email
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Documents
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Created At
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Last Login
                  </th>
                </tr>
              </thead>
              <tbody className="bg-white divide-y divide-gray-200">
                {users.map((user) => (
                  <tr key={user.username}>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="flex items-center">
                        <div className="h-8 w-8 rounded-full bg-blue-100 flex items-center justify-center">
                          <Users className="h-4 w-4 text-blue-600" />
                        </div>
                        <div className="ml-4">
                          <div className="text-sm font-medium text-gray-900">{user.username}</div>
                          <div className="text-sm text-gray-500">{user.phone}</div>
                        </div>
                      </div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <span className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${
                        user.role === 'admin' ? 'bg-purple-100 text-purple-800' : 'bg-green-100 text-green-800'
                      }`}>
                        {user.role}
                      </span>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                      {user.email}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                      <button
                        onClick={() => {
                          setSelectedUser(user.username);
                          setActiveTab('documents');
                        }}
                        className="text-blue-600 hover:text-blue-800"
                      >
                        {getDocumentCountByUser(user.username)} documents
                      </button>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                      {formatDate(user.createdAt)}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                      {user.lastLogin ? formatDate(user.lastLogin) : 'Never'}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Activity Log Tab */}
      {activeTab === 'activity' && (
        <div>
          <div className="bg-white shadow-md rounded-lg overflow-hidden">
            <div className="flow-root">
              <ul role="list" className="divide-y divide-gray-200">
                {activities.map((activity) => (
                  <li key={activity.id} className="px-6 py-4">
                    <div className="flex items-center space-x-4">
                      <div className={`h-8 w-8 rounded-full flex items-center justify-center ${
                        activity.action === 'login' ? 'bg-green-100' :
                        activity.action === 'logout' ? 'bg-red-100' :
                        activity.action === 'update_document' ? 'bg-yellow-100' : 'bg-blue-100'
                      }`}>
                        {activity.action === 'login' ? (
                          <Users className={`h-4 w-4 text-green-600`} />
                        ) : activity.action === 'logout' ? (
                          <LogOut className={`h-4 w-4 text-red-600`} />
                        ) : activity.action === 'update_document' ? (
                          <History className={`h-4 w-4 text-yellow-600`} />
                        ) : (
                          <Users className={`h-4 w-4 text-blue-600`} />
                        )}
                      </div>
                      <div className="flex-1 min-w-0">
                        <p className="text-sm font-medium text-gray-900 truncate">
                          {activity.username}
                        </p>
                        <p className="text-sm text-gray-500">
                          {activity.details}
                        </p>
                      </div>
                      <div className="text-sm text-gray-500">
                        {formatDate(activity.timestamp)}
                      </div>
                    </div>
                  </li>
                ))}
              </ul>
            </div>
          </div>
        </div>
      )}
      
      {/* Share Modal */}
      {showShareModal && selectedDocument && (
        <ShareModal 
          documentTitle={selectedDocument.title}
          onClose={() => setShowShareModal(false)}
          onShare={handleShare}
        />
      )}
    </div>
  );
};

export default ViewDocumentsPage;