import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { FileText, Upload, Users, Calendar, Hash, MapPin } from 'lucide-react';
import { useBlockchain } from '../context/BlockchainContext';
import { useAuth } from '../context/AuthContext';
import { Document } from '../types';

const AddDocumentPage: React.FC = () => {
  const { addBlock } = useBlockchain();
  const { user } = useAuth();
  const navigate = useNavigate();
  
  const [title, setTitle] = useState('');
  const [documentType, setDocumentType] = useState('');
  const [description, setDescription] = useState('');
  const [parties, setParties] = useState('');
  const [uid, setUid] = useState('');
  const [file, setFile] = useState<File | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [transactionResult, setTransactionResult] = useState<any>(null);
  const [location, setLocation] = useState<{ address: string; coordinates?: { latitude: number; longitude: number } } | null>(null);
  const [isLoadingLocation, setIsLoadingLocation] = useState(false);

  useEffect(() => {
    getLocation();
  }, []);

  // Redirect if not admin
  if (user?.role !== 'admin') {
    navigate('/login');
    return null;
  }

  const getLocation = () => {
    setIsLoadingLocation(true);
    if ("geolocation" in navigator) {
      navigator.geolocation.getCurrentPosition(
        position => {
          const { latitude, longitude } = position.coords;
          fetch(`https://api.opencagedata.com/geocode/v1/json?q=${latitude}+${longitude}&key=282d06b4edd240b4afbbd5202830fd3e`)
            .then(response => response.json())
            .then(data => {
              if (data.results && data.results[0]) {
                setLocation({
                  address: data.results[0].formatted,
                  coordinates: { latitude, longitude }
                });
              }
            })
            .catch(error => console.error('Error getting location:', error))
            .finally(() => setIsLoadingLocation(false));
        },
        error => {
          console.error('Error getting location:', error);
          setIsLoadingLocation(false);
        }
      );
    }
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files.length > 0) {
      setFile(e.target.files[0]);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    
    try {
      // Create a document object
      const newDocument: Document = {
        id: crypto.randomUUID(),
        title,
        documentType,
        description,
        parties: parties.split(',').map(p => p.trim()),
        uid,
        createdAt: new Date().toISOString(),
        fileUrl: file ? URL.createObjectURL(file) : undefined,
        hash: '', // Will be set by blockchain
        blockNumber: 0, // Will be set by blockchain
        previousHash: '', // Will be set by blockchain
        owner: user.username,
        location: location || undefined
      };
      
      // Add to blockchain
      const block = addBlock(newDocument);
      
      // Show transaction result
      setTransactionResult({
        success: true,
        blockNumber: block.blockNumber,
        hash: block.hash,
        timestamp: new Date(block.timestamp).toLocaleString()
      });
      
      // Reset form after 5 seconds
      setTimeout(() => {
        setTitle('');
        setDocumentType('');
        setDescription('');
        setParties('');
        setUid('');
        setFile(null);
        setTransactionResult(null);
        setIsSubmitting(false);
      }, 5000);
      
    } catch (error) {
      console.error('Error adding document:', error);
      setTransactionResult({
        success: false,
        error: 'Failed to add document to blockchain'
      });
      setIsSubmitting(false);
    }
  };

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="max-w-3xl mx-auto">
        <h1 className="text-2xl font-bold mb-6 flex items-center">
          <FileText className="mr-2 h-6 w-6" />
          Add Legal Document
        </h1>
        
        {transactionResult ? (
          <div className={`mb-6 p-4 rounded-md ${transactionResult.success ? 'bg-green-50 border border-green-200' : 'bg-red-50 border border-red-200'}`}>
            <h2 className="text-lg font-semibold mb-2">
              {transactionResult.success ? 'Document Added Successfully' : 'Error Adding Document'}
            </h2>
            
            {transactionResult.success ? (
              <div className="text-sm text-gray-700">
                <p className="mb-1"><strong>Transaction Hash:</strong> {transactionResult.hash}</p>
                <p className="mb-1"><strong>Block Number:</strong> {transactionResult.blockNumber}</p>
                <p className="mb-1"><strong>Timestamp:</strong> {transactionResult.timestamp}</p>
                <p className="mt-3 text-green-600 font-medium">Document has been securely stored in the blockchain.</p>
              </div>
            ) : (
              <p className="text-red-600">{transactionResult.error}</p>
            )}
          </div>
        ) : (
          <form onSubmit={handleSubmit} className="bg-white shadow-md rounded-lg p-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="col-span-2">
                <label htmlFor="title" className="block text-sm font-medium text-gray-700 mb-1">
                  Document Title
                </label>
                <input
                  type="text"
                  id="title"
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                  className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-blue-500 focus:border-blue-500"
                  required
                />
              </div>
              
              <div>
                <label htmlFor="documentType" className="block text-sm font-medium text-gray-700 mb-1">
                  Document Type
                </label>
                <select
                  id="documentType"
                  value={documentType}
                  onChange={(e) => setDocumentType(e.target.value)}
                  className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-blue-500 focus:border-blue-500"
                  required
                >
                  <option value="">Select a type</option>
                  <option value="Rent Agreement">Rent Agreement</option>
                  <option value="Property Deed">Property Deed</option>
                  <option value="Will">Will</option>
                  <option value="Power of Attorney">Power of Attorney</option>
                  <option value="Court Order">Court Order</option>
                  <option value="Contract">Contract</option>
                  <option value="Other">Other</option>
                </select>
              </div>
              
              <div>
                <label htmlFor="uid" className="block text-sm font-medium text-gray-700 mb-1">
                  UID Number
                </label>
                <input
                  type="text"
                  id="uid"
                  value={uid}
                  onChange={(e) => setUid(e.target.value)}
                  className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-blue-500 focus:border-blue-500"
                  required
                />
              </div>
              
              <div className="col-span-2">
                <label htmlFor="parties" className="block text-sm font-medium text-gray-700 mb-1">
                  Parties Involved (comma separated)
                </label>
                <div className="flex items-center">
                  <Users className="h-5 w-5 text-gray-400 mr-2" />
                  <input
                    type="text"
                    id="parties"
                    value={parties}
                    onChange={(e) => setParties(e.target.value)}
                    className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-blue-500 focus:border-blue-500"
                    placeholder="e.g. John Doe, Jane Smith"
                    required
                  />
                </div>
              </div>
              
              <div className="col-span-2">
                <label htmlFor="description" className="block text-sm font-medium text-gray-700 mb-1">
                  Description
                </label>
                <textarea
                  id="description"
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                  rows={4}
                  className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-blue-500 focus:border-blue-500"
                  required
                ></textarea>
              </div>

              <div className="col-span-2">
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Document Location
                </label>
                <div className="flex items-center space-x-2 p-3 bg-gray-50 rounded-md">
                  <MapPin className="h-5 w-5 text-gray-500" />
                  <span className="text-gray-700">
                    {isLoadingLocation ? (
                      'Fetching location...'
                    ) : location ? (
                      location.address
                    ) : (
                      'Location not available'
                    )}
                  </span>
                  {!isLoadingLocation && !location && (
                    <button
                      type="button"
                      onClick={getLocation}
                      className="ml-2 text-blue-600 hover:text-blue-800 text-sm"
                    >
                      Get Location
                    </button>
                  )}
                </div>
              </div>
              
              <div className="col-span-2">
                <label htmlFor="file" className="block text-sm font-medium text-gray-700 mb-1">
                  Upload Document
                </label>
                <div className="mt-1 flex justify-center px-6 pt-5 pb-6 border-2 border-gray-300 border-dashed rounded-md">
                  <div className="space-y-1 text-center">
                    <Upload className="mx-auto h-12 w-12 text-gray-400" />
                    <div className="flex text-sm text-gray-600">
                      <label
                        htmlFor="file"
                        className="relative cursor-pointer bg-white rounded-md font-medium text-blue-600 hover:text-blue-500 focus-within:outline-none"
                      >
                        <span>Upload a file</span>
                        <input
                          id="file"
                          name="file"
                          type="file"
                          className="sr-only"
                          onChange={handleFileChange}
                          required
                        />
                      </label>
                      <p className="pl-1">or drag and drop</p>
                    </div>
                    <p className="text-xs text-gray-500">
                      PDF, DOC, DOCX up to 10MB
                    </p>
                    {file && (
                      <p className="text-sm text-green-600">
                        Selected: {file.name}
                      </p>
                    )}
                  </div>
                </div>
              </div>
            </div>
            
            <div className="mt-6">
              <button
                type="submit"
                disabled={isSubmitting}
                className={`w-full flex justify-center py-2 px-4 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 ${isSubmitting ? 'opacity-70 cursor-not-allowed' : ''}`}
              >
                {isSubmitting ? (
                  <>
                    <svg className="animate-spin -ml-1 mr-3 h-5 w-5 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                      <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                      <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                    </svg>
                    Processing...
                  </>
                ) : (
                  <>
                    <Hash className="mr-2 h-5 w-5" />
                    Submit to Blockchain
                  </>
                )}
              </button>
            </div>
          </form>
        )}
      </div>
    </div>
  );
};

export default AddDocumentPage;