import React, { useState } from 'react';
import { Search } from 'lucide-react';
import { useBlockchain } from '../context/BlockchainContext';
import DocumentCard from '../components/DocumentCard';

const SearchPage: React.FC = () => {
  const [query, setQuery] = useState('');
  const [searchPerformed, setSearchPerformed] = useState(false);
  const { searchDocuments } = useBlockchain();
  const [results, setResults] = useState<any[]>([]);

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!query.trim()) return;
    
    const searchResults = searchDocuments(query);
    setResults(searchResults);
    setSearchPerformed(true);
  };

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="max-w-3xl mx-auto">
        <h1 className="text-2xl font-bold mb-6 text-center">Search Legal Documents</h1>
        
        <form onSubmit={handleSearch} className="mb-8">
          <div className="flex shadow-sm rounded-md">
            <input
              type="text"
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              className="flex-1 px-4 py-3 rounded-l-md border-y border-l border-gray-300 focus:ring-blue-500 focus:border-blue-500"
              placeholder="Search by name, document type, UID, or any keyword..."
            />
            <button
              type="submit"
              className="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-r-md shadow-sm text-white bg-blue-600 hover:bg-blue-700"
            >
              <Search className="h-5 w-5 mr-2" />
              Search
            </button>
          </div>
        </form>
        
        {searchPerformed && (
          <div className="mt-6">
            <h2 className="text-lg font-semibold mb-4">
              Search Results ({results.length})
            </h2>
            
            {results.length === 0 ? (
              <div className="bg-white rounded-lg shadow-md p-8 text-center">
                <p className="text-gray-500">No documents found matching your search criteria.</p>
              </div>
            ) : (
              <div className="space-y-6">
                {results.map(doc => (
                  <DocumentCard key={doc.id} document={doc} showDownload={false} />
                ))}
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
};

export default SearchPage;