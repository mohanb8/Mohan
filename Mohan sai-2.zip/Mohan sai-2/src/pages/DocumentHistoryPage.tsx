import React from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { ArrowLeft, History, Calendar, User, Hash, Database, MapPin } from 'lucide-react';
import { useBlockchain } from '../context/BlockchainContext';
import { Document } from '../types';

const DocumentHistoryPage: React.FC = () => {
  const { documentId } = useParams<{ documentId: string }>();
  const navigate = useNavigate();
  const { getDocumentHistory } = useBlockchain();

  const history = documentId ? getDocumentHistory(documentId) : [];
  const latestVersion = history[history.length - 1];

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleString('en-US', {
      year: 'numeric',
      month: 'long',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  if (!documentId || history.length === 0) {
    return (
      <div className="container mx-auto px-4 py-8">
        <div className="bg-white rounded-lg shadow-md p-8 text-center">
          <p className="text-gray-500">Document not found</p>
          <button
            onClick={() => navigate(-1)}
            className="mt-4 inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md text-white bg-blue-600 hover:bg-blue-700"
          >
            <ArrowLeft className="h-4 w-4 mr-2" />
            Go Back
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="max-w-4xl mx-auto">
        <div className="flex items-center justify-between mb-6">
          <h1 className="text-2xl font-bold flex items-center">
            <History className="mr-2 h-6 w-6" />
            Document Version History
          </h1>
          <button
            onClick={() => navigate(-1)}
            className="inline-flex items-center px-4 py-2 border border-gray-300 rounded-md shadow-sm text-sm font-medium text-gray-700 bg-white hover:bg-gray-50"
          >
            <ArrowLeft className="h-4 w-4 mr-2" />
            Back
          </button>
        </div>

        <div className="bg-blue-50 border border-blue-200 rounded-lg p-4 mb-6">
          <h2 className="text-lg font-semibold text-blue-800 mb-2">
            {latestVersion.title}
          </h2>
          <p className="text-sm text-blue-600">
            Latest version: v{latestVersion.version || 1}
          </p>
        </div>

        <div className="space-y-8">
          {history.map((version, index) => (
            <div 
              key={version.id}
              className={`relative pb-8 ${
                index < history.length - 1 ? 'border-l-2 border-gray-200' : ''
              }`}
            >
              <div className="relative flex items-start">
                <div className="absolute -left-[9px] bg-white">
                  <div className={`w-4 h-4 rounded-full border-2 ${
                    index === history.length - 1 ? 'border-blue-500 bg-blue-50' : 'border-gray-400 bg-white'
                  }`} />
                </div>
                
                <div className="ml-6">
                  <div className="flex items-center">
                    <span className={`text-sm font-medium ${
                      index === history.length - 1 ? 'text-blue-600' : 'text-gray-900'
                    }`}>
                      Version {version.version || 1}
                    </span>
                    {index === history.length - 1 && (
                      <span className="ml-2 px-2 py-0.5 text-xs font-medium bg-blue-100 text-blue-800 rounded-full">
                        Latest
                      </span>
                    )}
                  </div>
                  
                  <div className="mt-2 bg-white rounded-lg shadow-sm border border-gray-200 p-4">
                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <h4 className="text-sm font-medium text-gray-900 mb-2">Document Details</h4>
                        <div className="space-y-2 text-sm">
                          <p><span className="font-medium">Title:</span> {version.title}</p>
                          <p><span className="font-medium">Type:</span> {version.documentType}</p>
                          <p><span className="font-medium">UID:</span> {version.uid}</p>
                          <p><span className="font-medium">Parties:</span> {version.parties.join(', ')}</p>
                          <div>
                            <span className="font-medium">Description:</span>
                            <p className="mt-1 whitespace-pre-wrap text-gray-600">
                              {version.description}
                            </p>
                          </div>
                        </div>
                      </div>
                      
                      <div>
                        <h4 className="text-sm font-medium text-gray-900 mb-2">Metadata</h4>
                        <div className="space-y-2 text-sm">
                          <div className="flex items-center">
                            <Calendar className="h-4 w-4 text-gray-500 mr-2" />
                            <span>
                              {version.updatedAt 
                                ? `Updated: ${formatDate(version.updatedAt)}`
                                : `Created: ${formatDate(version.createdAt)}`
                              }
                            </span>
                          </div>
                          
                          <div className="flex items-center">
                            <User className="h-4 w-4 text-gray-500 mr-2" />
                            <span>Owner: {version.owner}</span>
                          </div>
                          
                          <div className="flex items-center">
                            <Hash className="h-4 w-4 text-gray-500 mr-2" />
                            <span className="truncate" title={version.hash}>
                              Hash: {version.hash.substring(0, 16)}...
                            </span>
                          </div>
                          
                          <div className="flex items-center">
                            <Database className="h-4 w-4 text-gray-500 mr-2" />
                            <span>Block: #{version.blockNumber}</span>
                          </div>
                          
                          {version.location && (
                            <div className="flex items-center">
                              <MapPin className="h-4 w-4 text-gray-500 mr-2" />
                              <span>Location: {version.location.address}</span>
                            </div>
                          )}
                        </div>
                      </div>
                    </div>

                    {version.fileUrl && (
                      <div className="mt-4 pt-3 border-t border-gray-200">
                        <a 
                          href={version.fileUrl}
                          download
                          className="inline-flex items-center text-sm text-blue-600 hover:text-blue-800"
                        >
                          <Database className="h-4 w-4 mr-2" />
                          Download Document Version
                        </a>
                      </div>
                    )}
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default DocumentHistoryPage;