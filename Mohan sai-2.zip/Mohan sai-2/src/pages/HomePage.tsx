import React from 'react';
import { Link } from 'react-router-dom';
import { Shield, Database, Lock, Search, FileText, UserCheck, Landmark, Lightbulb, Contact as FileContract, Scale } from 'lucide-react';

const HomePage: React.FC = () => {
  return (
    <div className="min-h-screen bg-gray-50">
      {/* Hero Section */}
      <div className="bg-gradient-to-r from-blue-800 to-blue-600 text-white py-16">
        <div className="container mx-auto px-4 text-center">
          <h1 className="text-4xl font-bold mb-4">Blockchain-Based E-Vault for Legal Records</h1>
          <p className="text-xl max-w-3xl mx-auto mb-8">
            Secure, tamper-proof storage for your most important legal documents using blockchain technology.
          </p>
          <div className="flex justify-center space-x-4">
            <Link 
              to="/login" 
              className="bg-white text-blue-700 px-6 py-3 rounded-lg font-semibold hover:bg-blue-50 transition"
            >
              Admin Login
            </Link>
            <Link 
              to="/search" 
              className="bg-transparent border-2 border-white px-6 py-3 rounded-lg font-semibold hover:bg-blue-700 transition"
            >
              Search Documents
            </Link>
          </div>
        </div>
      </div>

      {/* Features Section */}
      <div className="py-16 container mx-auto px-4">
        <h2 className="text-3xl font-bold text-center mb-12">Why Blockchain for Legal Records?</h2>
        
        <div className="grid md:grid-cols-3 gap-8">
          <div className="bg-white p-6 rounded-lg shadow-md">
            <div className="flex items-center mb-4">
              <Database className="h-8 w-8 text-blue-600 mr-3" />
              <h3 className="text-xl font-semibold">Decentralized Storage</h3>
            </div>
            <p className="text-gray-600">
              Documents are stored across multiple nodes, ensuring availability even if some nodes fail.
            </p>
          </div>
          
          <div className="bg-white p-6 rounded-lg shadow-md">
            <div className="flex items-center mb-4">
              <Lock className="h-8 w-8 text-blue-600 mr-3" />
              <h3 className="text-xl font-semibold">Enhanced Security</h3>
            </div>
            <p className="text-gray-600">
              Each block is encrypted and linked to previous blocks, making data tampering virtually impossible.
            </p>
          </div>
          
          <div className="bg-white p-6 rounded-lg shadow-md">
            <div className="flex items-center mb-4">
              <Shield className="h-8 w-8 text-blue-600 mr-3" />
              <h3 className="text-xl font-semibold">Data Verification</h3>
            </div>
            <p className="text-gray-600">
              Automatic verification of data integrity through hash codes ensures documents remain unaltered.
            </p>
          </div>
        </div>
      </div>

      {/* Applications Section */}
      <div className="bg-blue-50 py-16">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl font-bold text-center mb-12">Applications of Blockchain for Legal Records</h2>
          
          <div className="grid md:grid-cols-2 gap-8">
            <div className="bg-white p-6 rounded-lg shadow-md border-l-4 border-blue-500">
              <div className="flex items-center mb-4">
                <Landmark className="h-8 w-8 text-blue-600 mr-3" />
                <h3 className="text-xl font-semibold">Land Registry</h3>
              </div>
              <p className="text-gray-600">
                Create immutable and transparent records of land ownership, reducing fraud and disputes. 
                Blockchain provides a single source of truth for property transactions, eliminating the need 
                for intermediaries and reducing processing time.
              </p>
            </div>
            
            <div className="bg-white p-6 rounded-lg shadow-md border-l-4 border-green-500">
              <div className="flex items-center mb-4">
                <Lightbulb className="h-8 w-8 text-green-600 mr-3" />
                <h3 className="text-xl font-semibold">Intellectual Property Protection</h3>
              </div>
              <p className="text-gray-600">
                Securely and transparently manage intellectual property rights with timestamped proof of 
                creation and ownership. Blockchain creates an unalterable record of IP assets, simplifying 
                licensing, royalty payments, and dispute resolution.
              </p>
            </div>
            
            <div className="bg-white p-6 rounded-lg shadow-md border-l-4 border-purple-500">
              <div className="flex items-center mb-4">
                <FileContract className="h-8 w-8 text-purple-600 mr-3" />
                <h3 className="text-xl font-semibold">Contract Management</h3>
              </div>
              <p className="text-gray-600">
                Smart contracts automate execution and management of legal agreements, reducing human error 
                and enforcement costs. Self-executing contracts on blockchain ensure all parties fulfill 
                obligations without the need for intermediaries.
              </p>
            </div>
            
            <div className="bg-white p-6 rounded-lg shadow-md border-l-4 border-amber-500">
              <div className="flex items-center mb-4">
                <Scale className="h-8 w-8 text-amber-600 mr-3" />
                <h3 className="text-xl font-semibold">Evidence Management</h3>
              </div>
              <p className="text-gray-600">
                Securely and transparently manage evidence in legal proceedings with tamper-proof chain of 
                custody. Blockchain provides cryptographic proof that evidence hasn't been altered, 
                increasing trust in judicial systems and streamlining verification.
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* How It Works Section */}
      <div className="bg-gray-100 py-16">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl font-bold text-center mb-12">How It Works</h2>
          
          <div className="grid md:grid-cols-4 gap-6">
            <div className="bg-white p-5 rounded-lg shadow-sm text-center">
              <div className="bg-blue-100 w-12 h-12 rounded-full flex items-center justify-center mx-auto mb-4">
                <FileText className="h-6 w-6 text-blue-600" />
              </div>
              <h3 className="font-semibold mb-2">Document Upload</h3>
              <p className="text-gray-600 text-sm">Admin uploads legal documents with metadata</p>
            </div>
            
            <div className="bg-white p-5 rounded-lg shadow-sm text-center">
              <div className="bg-blue-100 w-12 h-12 rounded-full flex items-center justify-center mx-auto mb-4">
                <Database className="h-6 w-6 text-blue-600" />
              </div>
              <h3 className="font-semibold mb-2">Blockchain Storage</h3>
              <p className="text-gray-600 text-sm">Document is encrypted and added to the blockchain</p>
            </div>
            
            <div className="bg-white p-5 rounded-lg shadow-sm text-center">
              <div className="bg-blue-100 w-12 h-12 rounded-full flex items-center justify-center mx-auto mb-4">
                <Search className="h-6 w-6 text-blue-600" />
              </div>
              <h3 className="font-semibold mb-2">Document Search</h3>
              <p className="text-gray-600 text-sm">Users can search for documents by various criteria</p>
            </div>
            
            <div className="bg-white p-5 rounded-lg shadow-sm text-center">
              <div className="bg-blue-100 w-12 h-12 rounded-full flex items-center justify-center mx-auto mb-4">
                <UserCheck className="h-6 w-6 text-blue-600" />
              </div>
              <h3 className="font-semibold mb-2">Verified Access</h3>
              <p className="text-gray-600 text-sm">Admins can download files, users can view metadata</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default HomePage;