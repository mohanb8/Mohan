import React, { useState, useEffect } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import { Lock, User, Fingerprint, Shield, Smartphone, Mail, Phone, MapPin } from 'lucide-react';
import { useAuth } from '../context/AuthContext';

const LoginPage: React.FC = () => {
  const { login, signup, verifyAadhaar, verifyBiometric, currentAuthStep, user } = useAuth();
  const navigate = useNavigate();
  const location = useLocation();
  
  // Login/Signup mode
  const [isSignup, setIsSignup] = useState(false);
  
  // Step 1: Credentials
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  
  // Additional signup fields
  const [email, setEmail] = useState('');
  const [phone, setPhone] = useState('');
  const [aadhaarNumber, setAadhaarNumber] = useState('');
  
  // Location state
  const [userLocation, setUserLocation] = useState<{
    address: string;
    coordinates?: { latitude: number; longitude: number };
  } | null>(null);
  const [isLoadingLocation, setIsLoadingLocation] = useState(false);
  
  // Step 2: Aadhaar & OTP
  const [aadhaar, setAadhaar] = useState('');
  const [otp, setOtp] = useState('');
  const [otpSent, setOtpSent] = useState(false);
  
  // Step 3: Biometric
  const [biometricData, setBiometricData] = useState('');
  
  // Error handling
  const [error, setError] = useState('');
  const [successMessage, setSuccessMessage] = useState('');
  const [loading, setLoading] = useState(false);

  // Get the redirect path from location state or default to home
  const from = location.state?.from?.pathname || '/';

  // Auto-fill Aadhaar for demo purposes
  useEffect(() => {
    if (currentAuthStep === 'aadhaar' && username === 'admin') {
      setAadhaar('123456789012');
    } else if (currentAuthStep === 'aadhaar' && username === 'user') {
      setAadhaar('987654321098');
    }
  }, [currentAuthStep, username]);

  // Get user location
  const getLocation = () => {
    setIsLoadingLocation(true);
    if ("geolocation" in navigator) {
      navigator.geolocation.getCurrentPosition(
        position => {
          const { latitude, longitude } = position.coords;
          fetch(`https://api.opencagedata.com/geocode/v1/json?q=${latitude}+${longitude}&key=282d06b4edd240b4afbbd5202830fd3e`)
            .then(response => response.json())
            .then(data => {
              if (data.results && data.results[0]) {
                setUserLocation({
                  address: data.results[0].formatted,
                  coordinates: { latitude, longitude }
                });
              }
            })
            .catch(error => {
              console.error('Error getting location:', error);
              setError('Failed to get location. Please try again.');
            })
            .finally(() => setIsLoadingLocation(false));
        },
        error => {
          console.error('Error getting location:', error);
          setError('Location access denied. Please enable location services.');
          setIsLoadingLocation(false);
        }
      );
    }
  };

  // Redirect if already authenticated
  useEffect(() => {
    if (user && currentAuthStep === 'complete') {
      if (user.role === 'admin') {
        navigate('/admin/view-documents');
      } else {
        navigate('/user/documents');
      }
    }
  }, [user, currentAuthStep, navigate]);

  const handleCredentialsSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setSuccessMessage('');
    
    if (!username || !password) {
      setError('Please enter both username and password');
      return;
    }

    if (isSignup) {
      if (!email || !phone || !aadhaarNumber || !userLocation) {
        setError('Please fill in all required fields including location');
        return;
      }

      const success = signup({
        username,
        password,
        role: 'user',
        email,
        phone,
        aadhaar: aadhaarNumber,
        biometricId: `bio-${Date.now()}`,
        location: userLocation
      });

      if (!success) {
        setError('Username already exists');
        return;
      }

      // Switch to login mode after successful signup
      setIsSignup(false);
      setSuccessMessage('Account created successfully! Please log in.');
      return;
    }
    
    const success = login(username, password);
    
    if (!success) {
      setError('Invalid username or password');
    }
  };
  
  const sendOtp = () => {
    if (!aadhaar || aadhaar.length !== 12 || !/^\d+$/.test(aadhaar)) {
      setError('Please enter a valid 12-digit Aadhaar number');
      return;
    }
    
    setLoading(true);
    
    // Simulate OTP sending
    setTimeout(() => {
      setOtpSent(true);
      setLoading(false);
      setError('');
    }, 1500);
  };
  
  const handleAadhaarSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    
    if (!aadhaar || !otp) {
      setError('Please enter both Aadhaar number and OTP');
      return;
    }
    
    if (otp.length !== 6 || !/^\d+$/.test(otp)) {
      setError('OTP must be 6 digits');
      return;
    }
    
    const success = verifyAadhaar(aadhaar, otp);
    
    if (!success) {
      setError('Invalid Aadhaar number or OTP');
    }
  };
  
  const handleBiometricSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    
    if (!biometricData) {
      setError('Please scan your fingerprint first');
      return;
    }
    
    const success = verifyBiometric(biometricData);
    
    if (!success) {
      setError('Biometric verification failed');
    } else {
      // Navigate to the appropriate page based on user role
      if (user?.role === 'admin') {
        navigate('/admin/view-documents');
      } else {
        navigate('/user/documents');
      }
    }
  };
  
  const simulateBiometricScan = () => {
    setLoading(true);
    
    // Simulate biometric scanning
    setTimeout(() => {
      setBiometricData('simulated-biometric-data-' + Date.now());
      setLoading(false);
    }, 2000);
  };

  return (
    <div className="min-h-screen bg-gray-100 flex items-center justify-center py-12 px-4 sm:px-6 lg:px-8">
      <div className="max-w-md w-full space-y-8 bg-white p-8 rounded-lg shadow-md">
        <div className="text-center">
          <h2 className="text-3xl font-extrabold text-gray-900">
            {isSignup ? 'Create an Account' : 'Sign in to E-Vault'}
          </h2>
          <p className="mt-2 text-sm text-gray-600">
            {isSignup ? 'Create your account to get started' : 'Three-factor authentication required'}
          </p>
        </div>
        
        {error && (
          <div className="bg-red-50 border-l-4 border-red-500 p-4 mb-4">
            <div className="flex">
              <div className="flex-shrink-0">
                <svg className="h-5 w-5 text-red-500" viewBox="0 0 20 20" fill="currentColor">
                  <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zM8.707 7.293a1 1 0 00-1.414 1.414L8.586 10l-1.293 1.293a1 1 0 101.414 1.414L10 11.414l1.293 1.293a1 1 0 001.414-1.414L11.414 10l1.293-1.293a1 1 0 00-1.414-1.414L10 8.586 8.707 7.293z" clipRule="evenodd" />
                </svg>
              </div>
              <div className="ml-3">
                <p className="text-sm text-red-700">{error}</p>
              </div>
            </div>
          </div>
        )}

        {successMessage && (
          <div className="bg-green-50 border-l-4 border-green-500 p-4 mb-4">
            <div className="flex">
              <div className="flex-shrink-0">
                <svg className="h-5 w-5 text-green-500" viewBox="0 0 20 20" fill="currentColor">
                  <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clipRule="evenodd" />
                </svg>
              </div>
              <div className="ml-3">
                <p className="text-sm text-green-700">{successMessage}</p>
              </div>
            </div>
          </div>
        )}
        
        {/* Authentication Steps */}
        {!isSignup && (
          <div className="flex items-center justify-between mb-6">
            <div className={`flex flex-col items-center ${currentAuthStep === 'credentials' ? 'text-blue-600' : 'text-gray-400'}`}>
              <div className={`w-8 h-8 rounded-full flex items-center justify-center ${currentAuthStep === 'credentials' ? 'bg-blue-100 border-2 border-blue-600' : 'bg-gray-100'}`}>
                <User className="h-4 w-4" />
              </div>
              <span className="text-xs mt-1">Credentials</span>
            </div>
            
            <div className="flex-1 h-0.5 mx-2 bg-gray-200"></div>
            
            <div className={`flex flex-col items-center ${currentAuthStep === 'aadhaar' ? 'text-blue-600' : 'text-gray-400'}`}>
              <div className={`w-8 h-8 rounded-full flex items-center justify-center ${currentAuthStep === 'aadhaar' ? 'bg-blue-100 border-2 border-blue-600' : 'bg-gray-100'}`}>
                <Smartphone className="h-4 w-4" />
              </div>
              <span className="text-xs mt-1">Aadhaar & OTP</span>
            </div>
            
            <div className="flex-1 h-0.5 mx-2 bg-gray-200"></div>
            
            <div className={`flex flex-col items-center ${currentAuthStep === 'biometric' ? 'text-blue-600' : 'text-gray-400'}`}>
              <div className={`w-8 h-8 rounded-full flex items-center justify-center ${currentAuthStep === 'biometric' ? 'bg-blue-100 border-2 border-blue-600' : 'bg-gray-100'}`}>
                <Fingerprint className="h-4 w-4" />
              </div>
              <span className="text-xs mt-1">Biometric</span>
            </div>
          </div>
        )}
        
        {/* Step 1: Credentials */}
        {(currentAuthStep === 'credentials' || isSignup) && (
          <form className="mt-8 space-y-6" onSubmit={handleCredentialsSubmit}>
            <div className="rounded-md shadow-sm -space-y-px">
              <div className="mb-4">
                <label htmlFor="username" className="block text-sm font-medium text-gray-700 mb-1">
                  Username
                </label>
                <div className="relative">
                  <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                    <User className="h-5 w-5 text-gray-400" />
                  </div>
                  <input
                    id="username"
                    name="username"
                    type="text"
                    autoComplete="username"
                    value={username}
                    onChange={(e) => setUsername(e.target.value)}
                    className="focus:ring-blue-500 focus:border-blue-500 block w-full pl-10 pr-3 py-2 border border-gray-300 rounded-md"
                    placeholder="Username"
                  />
                </div>
              </div>
              
              <div>
                <label htmlFor="password" className="block text-sm font-medium text-gray-700 mb-1">
                  Password
                </label>
                <div className="relative">
                  <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                    <Lock className="h-5 w-5 text-gray-400" />
                  </div>
                  <input
                    id="password"
                    name="password"
                    type="password"
                    autoComplete="current-password"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    className="focus:ring-blue-500 focus:border-blue-500 block w-full pl-10 pr-3 py-2 border border-gray-300 rounded-md"
                    placeholder="Password"
                  />
                </div>
              </div>

              {isSignup && (
                <>
                  <div className="mt-4">
                    <label htmlFor="email" className="block text-sm font-medium text-gray-700 mb-1">
                      Email
                    </label>
                    <div className="relative">
                      <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                        <Mail className="h-5 w-5 text-gray-400" />
                      </div>
                      <input
                        id="email"
                        name="email"
                        type="email"
                        value={email}
                        onChange={(e) => setEmail(e.target.value)}
                        className="focus:ring-blue-500 focus:border-blue-500 block w-full pl-10 pr-3 py-2 border border-gray-300 rounded-md"
                        placeholder="you@example.com"
                      />
                    </div>
                  </div>

                  <div className="mt-4">
                    <label htmlFor="phone" className="block text-sm font-medium text-gray-700 mb-1">
                      Phone Number
                    </label>
                    <div className="relative">
                      <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                        <Phone className="h-5 w-5 text-gray-400" />
                      </div>
                      <input
                        id="phone"
                        name="phone"
                        type="tel"
                        value={phone}
                        onChange={(e) => setPhone(e.target.value)}
                        className="focus:ring-blue-500 focus:border-blue-500 block w-full pl-10 pr-3 py-2 border border-gray-300 rounded-md"
                        placeholder="+91 98765 43210"
                      />
                    </div>
                  </div>

                  <div className="mt-4">
                    <label htmlFor="aadhaarNumber" className="block text-sm font-medium text-gray-700 mb-1">
                      Aadhaar Number
                    </label>
                    <div className="relative">
                      <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                        <Shield className="h-5 w-5 text-gray-400" />
                      </div>
                      <input
                        id="aadhaarNumber"
                        name="aadhaarNumber"
                        type="text"
                        value={aadhaarNumber}
                        onChange={(e) => setAadhaarNumber(e.target.value)}
                        className="focus:ring-blue-500 focus:border-blue-500 block w-full pl-10 pr-3 py-2 border border-gray-300 rounded-md"
                        placeholder="12-digit Aadhaar number"
                        maxLength={12}
                      />
                    </div>
                  </div>

                  <div className="mt-4">
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Location
                    </label>
                    <div className="relative">
                      <div className="flex items-center space-x-2 p-3 bg-gray-50 rounded-md">
                        <MapPin className="h-5 w-5 text-gray-500" />
                        <span className="text-gray-700">
                          {isLoadingLocation ? (
                            'Fetching location...'
                          ) : userLocation ? (
                            userLocation.address
                          ) : (
                            'Location not available'
                          )}
                        </span>
                        {!isLoadingLocation && !userLocation && (
                          <button
                            type="button"
                            onClick={getLocation}
                            className="ml-2 text-blue-600 hover:text-blue-800 text-sm"
                          >
                            Get Location
                          </button>
                        )}
                      </div>
                    </div>
                  </div>
                </>
              )}
            </div>

            <div>
              <button
                type="submit"
                className="group relative w-full flex justify-center py-2 px-4 border border-transparent text-sm font-medium rounded-md text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
              >
                <span className="absolute left-0 inset-y-0 flex items-center pl-3">
                  <Shield className="h-5 w-5 text-blue-500 group-hover:text-blue-400" />
                </span>
                {isSignup ? 'Create Account' : 'Continue'}
              </button>
            </div>
            
            <div className="text-sm text-center">
              {isSignup ? (
                <p className="text-gray-600">
                  Already have an account?{' '}
                  <button
                    type="button"
                    onClick={() => setIsSignup(false)}
                    className="text-blue-600 hover:text-blue-500"
                  >
                    Sign in
                  </button>
                </p>
              ) : (
                <>
                  <p className="text-gray-600 mb-2">
                    Don't have an account?{' '}
                    <button
                      type="button"
                      onClick={() => setIsSignup(true)}
                      className="text-blue-600 hover:text-blue-500"
                    >
                      Sign up
                    </button>
                  </p>
                  <p className="text-gray-600">
                    Demo credentials: admin/admin or user/user
                  </p>
                </>
              )}
            </div>
          </form>
        )}
        
        {/* Step 2: Aadhaar & OTP */}
        {currentAuthStep === 'aadhaar' && (
          <form className="mt-8 space-y-6" onSubmit={handleAadhaarSubmit}>
            <div>
              <label htmlFor="aadhaar" className="block text-sm font-medium text-gray-700 mb-1">
                Aadhaar Number
              </label>
              <div className="relative">
                <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                  <Shield className="h-5 w-5 text-gray-400" />
                </div>
                <input
                  id="aadhaar"
                  name="aadhaar"
                  type="text"
                  value={aadhaar}
                  onChange={(e) => setAadhaar(e.target.value)}
                  className="focus:ring-blue-500 focus:border-blue-500 block w-full pl-10 pr-3 py-2 border border-gray-300 rounded-md"
                  placeholder="12-digit Aadhaar number"
                  maxLength={12}
                />
              </div>
            </div>
            
            {!otpSent ? (
              <div>
                <button
                  type="button"
                  onClick={sendOtp}
                  disabled={loading}
                  className={`w-full flex justify-center py-2 px-4 border border-transparent text-sm font-medium rounded-md text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 ${loading ? 'opacity-70 cursor-not-allowed' : ''}`}
                >
                  {loading ? (
                    <>
                      <svg className="animate-spin -ml-1 mr-3 h-5 w-5 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                        <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                        <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                      </svg>
                      Sending OTP...
                    </>
                  ) : (
                    <>Send OTP</>
                  )}
                </button>
                
                <div className="mt-4 text-sm text-center">
                  <p className="text-gray-600">
                    For demo, use Aadhaar: 123456789012 (admin) or 987654321098 (user)
                  </p>
                </div>
              </div>
            ) : (
              <>
                <div>
                  <label htmlFor="otp" className="block text-sm font-medium text-gray-700 mb-1">
                    OTP
                  </label>
                  <div className="relative">
                    <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                      <Smartphone className="h-5 w-5 text-gray-400" />
                    </div>
                    <input
                      id="otp"
                      name="otp"
                      type="text"
                      value={otp}
                      onChange={(e) => setOtp(e.target.value)}
                      className="focus:ring-blue-500 focus:border-blue-500 block w-full pl-10 pr-3 py-2 border border-gray-300 rounded-md"
                      placeholder="6-digit OTP"
                      maxLength={6}
                    />
                  </div>
                  <p className="mt-2 text-sm text-gray-500">
                    OTP sent to registered mobile number (For demo, use any 6 digits)
                  </p>
                </div>
                
                <div>
                  <button
                    type="submit"
                    className="w-full flex justify-center py-2 px-4 border border-transparent text-sm font-medium rounded-md text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
                  >
                    Verify OTP
                  </button>
                </div>
              </>
            )}
          </form>
        )}
        
        {/* Step 3: Biometric */}
        {currentAuthStep === 'biometric' && (
          <div className="mt-8 space-y-6">
            <div className="text-center">
              <Fingerprint className="h-16 w-16 text-blue-600 mx-auto mb-4" />
              <h3 className="text-lg font-medium text-gray-900 mb-2">Biometric Verification</h3>
              <p className="text-sm text-gray-500 mb-6">
                Please scan your fingerprint to complete the authentication process
              </p>
              
              {!biometricData ? (
                <button
                  onClick={simulateBiometricScan}
                  disabled={loading}
                  className={`w-full flex justify-center py-3 px-4 border border-transparent text-sm font-medium rounded-md text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 ${loading ? 'opacity-70 cursor-not-allowed' : ''}`}
                >
                  {loading ? (
                    <>
                      <svg className="animate-spin -ml-1 mr-3 h-5 w-5 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                        <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                        <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                      </svg>
                      Scanning...
                    </>
                  ) : (
                    <>Scan Fingerprint</>
                  )}
                </button>
              ) : (
                <form onSubmit={handleBiometricSubmit}>
                  <div className="bg-green-50 border border-green-200 rounded-md p-4 mb-4">
                    <div className="flex">
                      <div className="flex-shrink-0">
                        <svg className="h-5 w-5 text-green-400" viewBox="0 0 20 20" fill="currentColor">
                          <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clipRule="evenodd" />
                        </svg>
                      </div>
                      <div className="ml-3">
                        <p className="text-sm text-green-700">Fingerprint scan successful</p>
                      </div>
                    </div>
                  </div>
                  
                  <button
                    type="submit"
                    className="w-full flex justify-center py-2 px-4 border border-transparent text-sm font-medium rounded-md text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
                  >
                    Complete Authentication
                  </button>
                </form>
              )}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default LoginPage;