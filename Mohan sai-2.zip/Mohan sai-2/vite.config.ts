import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';
import { Buffer } from 'buffer';

export default defineConfig({
  plugins: [react()],
  optimizeDeps: {
    exclude: ['lucide-react'],
  },
  server: {
    proxy: {
      '/api': {
        target: 'http://localhost:3000',
        changeOrigin: true,
        rewrite: (path) => path.replace(/^\/api/, ''),
      },
    },
  },
  define: {
    'process.env': {
      TWILIO_ACCOUNT_SID: JSON.stringify(process.env.TWILIO_ACCOUNT_SID),
      TWILIO_AUTH_TOKEN: JSON.stringify(process.env.TWILIO_AUTH_TOKEN),
      TWILIO_WHATSAPP_NUMBER: JSON.stringify(process.env.TWILIO_WHATSAPP_NUMBER),
    },
    global: {},
    'global.Buffer': Buffer,
  },
});